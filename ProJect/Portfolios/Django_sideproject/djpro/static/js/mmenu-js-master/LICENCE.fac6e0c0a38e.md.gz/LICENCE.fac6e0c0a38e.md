# License information

The mmenu.js plugin is free to use for personal or non-profit usage. 
You can purchase a license if you want to use it in a commercial project.


#### For personal or non-profit usage:
The mmenu.js plugin is licensed under [the CC-BY-NC-4.0](http://creativecommons.org/licenses/by-nc/4.0/)  license.


#### After purchasing a license key:
The mmenu.js plugin is licensed under the [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) license.

For more information, please visit [the documentation](https://mmenujs.com/download.html).

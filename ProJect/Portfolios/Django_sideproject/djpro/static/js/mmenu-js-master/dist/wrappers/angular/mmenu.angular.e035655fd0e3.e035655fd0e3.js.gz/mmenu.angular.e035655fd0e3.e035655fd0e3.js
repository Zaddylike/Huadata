export default function () {
    this.opts.onClick = {
        close: true,
        preventDefault: false,
        setSelected: true
    };
}
;

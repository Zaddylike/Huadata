export default {
    'Close menu': 'Fechar menu',
    'Close submenu': 'Fechar submenu',
    'Open submenu': 'Abrir submenu',
    'Toggle submenu': 'Alternar submenu'
};

export default {
    'Close menu': 'Menu sluiten',
    'Close submenu': 'Submenu sluiten',
    'Open submenu': 'Submenu openen',
    'Toggle submenu': 'Submenu wisselen'
};
